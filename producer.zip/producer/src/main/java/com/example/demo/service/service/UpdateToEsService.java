package com.example.demo.service.service;

import com.example.demo.pojo.Question;

public interface UpdateToEsService {

    public boolean UpdateToLikeEsService(String question_id,int sum);
}
